using UnityEngine;

[RequireComponent(typeof(LineRenderer))]
public class RingDrawer : MonoBehaviour
{
    public enum RingMode { HeightMarker, RadiusTarget }

    [Header("Reference")]
    public Transform targetBody;

    [Header("General")]
    [Tooltip("How precise the user must be to count as 'correct'.")]
    public float margin = 0.01f;
    [Tooltip("How long the user must remain within the margin to lock correctness.")]
    public float requiredHoldTime = 0.1f;

    [Header("Colors")]
    public Color correctColor = Color.blue;
    public Color defaultColor = Color.red;

    [Header("Line")]
    public int segments = 100;
    public float lineWidth = 0.02f;

    [Header("Mode")]
    public RingMode mode = RingMode.HeightMarker;

    [Header("Phase 1: Height Marker (world-units above center)")]
    [Tooltip("World-space height above the planet center where the ring's top should align to the planet's top (Phase 1).")]
    public float targetHeight = 0.55f;
    [Tooltip("Visual hoop size for Phase 1 (doesn't affect correctness).")]
    public float ringRadius = 0.5f;

    [Header("Phase 2: Radius Target (world-units radius)")]
    [Tooltip("Target radius (world units) used in Phase 2.")]
    [SerializeField] private float targetRadius = 0.5f;

    // Runtime
    public bool IsScaledCorrectly { get; private set; }
    public float TargetRadius => targetRadius; // expose for snap logic in scaler

    private LineRenderer lineRenderer;
    private float holdTimer = 0f;

    const string MaterialName = "Sprites/Default";

    void Awake()
    {
        lineRenderer = GetComponent<LineRenderer>();
        lineRenderer.useWorldSpace = true;
        lineRenderer.loop = true;
        lineRenderer.positionCount = Mathf.Max(3, segments);
        lineRenderer.widthMultiplier = lineWidth;
        lineRenderer.material = new Material(Shader.Find(MaterialName));
        SetRingColor(defaultColor);
    }

    void Update()
    {
        if (!targetBody) return;

        // 1) Validate
        bool currentlyCorrect = false;

        if (mode == RingMode.HeightMarker)
        {
            // Planet top in world Y
            float planetTopY = targetBody.position.y + (targetBody.localScale.y * 0.5f);
            // Where the ring expects the top to be (center + targetHeight)
            float targetRingTopY = targetBody.position.y + targetHeight;

            currentlyCorrect = Mathf.Abs(planetTopY - targetRingTopY) <= margin;
        }
        else // RadiusTarget
        {
            float currentRadius = GetCurrentPlanetRadius();
            currentlyCorrect = Mathf.Abs(currentRadius - targetRadius) <= margin;
        }

        // 2) Hold-time logic
        if (currentlyCorrect)
        {
            holdTimer += Time.deltaTime;
            if (!IsScaledCorrectly && holdTimer >= requiredHoldTime)
                IsScaledCorrectly = true;
            SetRingColor(correctColor);
        }
        else
        {
            holdTimer = 0f;
            IsScaledCorrectly = false;
            SetRingColor(defaultColor);
        }

        // 3) Draw (updates position each frame in case things move)
        if (mode == RingMode.HeightMarker)
            DrawHeightMarker();
        else
            DrawRadiusTarget();
    }

    // --------------------------- Public API ---------------------------

    /// <summary>Switch between Phase 1 and Phase 2 rendering/validation.</summary>
    public void SetMode(RingMode newMode)
    {
        mode = newMode;
        ResetHold();
        // Force a redraw next Update by tweaking positionCount (harmless)
        lineRenderer.positionCount = Mathf.Max(3, segments);
    }

    /// <summary>Phase 2: set the absolute target radius (world units).</summary>
    public void SetStaticTarget(float newTargetRadius)
    {
        targetRadius = Mathf.Max(0.0001f, newTargetRadius);
        mode = RingMode.RadiusTarget;
        ResetHold();
    }

    /// <summary>Resets the hold timer and correctness state.</summary>
    public void ResetHold()
    {
        holdTimer = 0f;
        IsScaledCorrectly = false;
    }

    /// <summary>
    /// Legacy-style setter from your earlier version. In Phase 1 this changes the visual,
    /// in Phase 2 it behaves like SetStaticTarget(newRadius).
    /// </summary>
    public void SetRingRadius(float newRadius)
    {
        if (mode == RingMode.HeightMarker)
        {
            ringRadius = Mathf.Max(0.0001f, newRadius);
            targetHeight = Mathf.Max(0.0001f, newRadius); // keep your earlier coupling if you rely on it
        }
        else
        {
            SetStaticTarget(newRadius);
        }
        ResetHold();
    }

    // --------------------------- Drawing ---------------------------

    /// <summary>
    /// Phase 1: Draw a vertical circle (YZ plane) whose **top** sits at (center.y + targetHeight).
    /// Visual-only radius = ringRadius (does not affect correctness).
    /// </summary>
    private void DrawHeightMarker()
    {
        int n = Mathf.Max(3, segments);
        if (lineRenderer.positionCount != n) lineRenderer.positionCount = n;

        Vector3[] pts = new Vector3[n];
        float step = 360f / n;

        // Place the circle so its top touches the target height:
        // center.y + ringRadius == targetBody.position.y + targetHeight
        float centerY = targetBody.position.y + (targetHeight - ringRadius);
        Vector3 center = new Vector3(targetBody.position.x, centerY, targetBody.position.z);

        for (int i = 0; i < n; i++)
        {
            float ang = Mathf.Deg2Rad * (i * step);
            float y = Mathf.Sin(ang) * ringRadius;
            float z = Mathf.Cos(ang) * ringRadius;
            pts[i] = center + new Vector3(0f, y, z); // circle in YZ plane
        }

        lineRenderer.SetPositions(pts);
    }

    /// <summary>
    /// Phase 2: Draw a vertical circle (YZ plane) centered on the planet with radius = targetRadius.
    /// </summary>
    private void DrawRadiusTarget()
    {
        int n = Mathf.Max(3, segments);
        if (lineRenderer.positionCount != n) lineRenderer.positionCount = n;

        Vector3[] pts = new Vector3[n];
        float step = 360f / n;

        Vector3 center = targetBody.position;

        for (int i = 0; i < n; i++)
        {
            float ang = Mathf.Deg2Rad * (i * step);
            float y = Mathf.Sin(ang) * targetRadius;
            float z = Mathf.Cos(ang) * targetRadius;
            pts[i] = center + new Vector3(0f, y, z); // circle in YZ plane
        }

        lineRenderer.SetPositions(pts);
    }

    // --------------------------- Helpers ---------------------------

    private float GetCurrentPlanetRadius()
    {
        // If your meshes are unit spheres scaled uniformly, this is fine.
        // If not, you could use mesh bounds to compute an accurate world radius.
        Vector3 s = targetBody.localScale;
        return Mathf.Max(s.x, s.y, s.z) * 0.5f; // treat scale as diameter; radius = half
    }

    private void SetRingColor(Color c)
    {
        lineRenderer.startColor = c;
        lineRenderer.endColor = c;
    }
}

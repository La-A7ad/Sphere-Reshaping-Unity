using UnityEngine;

public class GameManager : MonoBehaviour
{
    public enum Phase { PullToSphere, UniformResize }
    [Header("Phase")]
    public Phase phase = Phase.PullToSphere;

    [Header("Controllers")]
    public YScaler yScalerScript;   // assign in Inspector
    public Scaler  scalerScript;    // assign in Inspector

    [Header("Rings")]
    public RingDrawer earthRing;    // Earth ring component
    public RingDrawer moonRing;     // Moon ring component
    public RingDrawer sunRing;      // Sun ring component

    [Header("Planets")]
    public Transform earth;         // Earth root transform (baseline)

    [Header("Phase 2 Target Ratios (relative to Earth)")]
    [Tooltip("Moon radius relative to Earth in Phase 2")]
    public float moonToEarthRatio = 0.27f;
    [Tooltip("Sun radius relative to Earth in Phase 2")]
    public float sunToEarthRatio  = 109f;

    [Header("Audio (optional)")]
    public AudioSource audioSource;
    public AudioClip   phase2Clip;
    public AudioClip   finishClip;

    private bool phase2Announced = false;
    private bool finishedAnnounced = false;

    void Start()
    {
        SetPhase(Phase.PullToSphere);
    }

    void Update()
    {
        if (phase == Phase.PullToSphere)
        {
            if (AllPlanetsScaledCorrectly())
            {
                SetPhase(Phase.UniformResize);
                SetupPhase2Targets();

                if (!phase2Announced && audioSource && phase2Clip)
                {
                    audioSource.PlayOneShot(phase2Clip);
                    phase2Announced = true;
                }
            }
        }
        else if (phase == Phase.UniformResize)
        {
            if (AllPlanetsScaledCorrectly())
            {
                if (!finishedAnnounced && audioSource && finishClip)
                {
                    audioSource.PlayOneShot(finishClip);
                    finishedAnnounced = true;
                }
                // TODO: advance game flow, UI, etc.
            }
        }
    }

    public void SetPhase(Phase p)
    {
        phase = p;

        if (yScalerScript) yScalerScript.enabled = (p == Phase.PullToSphere);
        if (scalerScript)  scalerScript.enabled  = (p == Phase.UniformResize);
    }

    public bool AllPlanetsScaledCorrectly()
    {
        // All 3 rings must report correct (with their own hold timers)
        return earthRing && moonRing && sunRing
            && earthRing.IsScaledCorrectly
            && moonRing.IsScaledCorrectly
            && sunRing.IsScaledCorrectly;
    }

    float GetEarthRadius()
    {
        if (!earth) return 0.5f;
        var s = earth.localScale;
        // Treat localScale as diameter on each axis; radius = half of the largest axis
        return Mathf.Max(s.x, s.y, s.z) * 0.5f;
    }

    public void SetupPhase2Targets()
    {
        // Switch rings to radius targets based on Earth’s current radius
        float earthR = GetEarthRadius();
        if (earthRing) { earthRing.SetStaticTarget(earthR); earthRing.ResetHold(); }
        if (moonRing)  { moonRing.SetStaticTarget(earthR * Mathf.Max(0.0001f, moonToEarthRatio)); moonRing.ResetHold(); }
        if (sunRing)   { sunRing.SetStaticTarget(earthR * Mathf.Max(0.0001f, sunToEarthRatio));   sunRing.ResetHold(); }
    }
}

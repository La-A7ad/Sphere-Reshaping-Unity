using UnityEngine;
using UnityEngine.EventSystems;

[DisallowMultipleComponent]
public class YScaler : MonoBehaviour
{
    [Header("Planets")]
    [SerializeField] public Transform Sun;
    [SerializeField] public Transform Earth;
    [SerializeField] public Transform Moon;

    [Header("Selection")]
    [Tooltip("Only these layers will be raycast-selected.")]
    [SerializeField] private LayerMask selectableLayers = ~0;
    [Tooltip("If true, hits that don't match direct refs can still match by tag.")]
    [SerializeField] private bool allowTagFallback = true;

    [Header("Scaling")]
    [Tooltip("Pixels of mouse movement → Y-scale change.")]
    [SerializeField] private float dragSensitivity = 0.0025f;
    [Tooltip("Smallest allowed axis value to avoid collapsing/inverting.")]
    [SerializeField] private float minAxis = 0.1f;

    // Runtime
    private Transform selectedObject;
    private Vector3 lastMousePosition;
    private bool isDragging;

    // ---------- Unity ----------
    private void Update()
    {
        if (!enabled) return;

        // Begin drag
        if (Input.GetMouseButtonDown(0))
            TryBeginDrag();

        // Perform drag
        if (isDragging && selectedObject)
        {
            Vector3 delta = Input.mousePosition - lastMousePosition;

            // Convert pixel delta to a Y-scale change
            float yDelta = delta.y * dragSensitivity;

            // Apply Y-only scaling with clamp
            Vector3 s = selectedObject.localScale;
            float maxXZ = Mathf.Max(s.x, s.z); // cap Y at the largest horizontal axis
            s.y = Mathf.Clamp(s.y + yDelta, minAxis, maxXZ);
            selectedObject.localScale = s;

            lastMousePosition = Input.mousePosition;

            if (Input.GetMouseButtonUp(0))
            {
                isDragging = false;
                Debug.Log("[YScaler] Drag end.");
            }
        }

        if (Input.GetMouseButtonUp(0))
            isDragging = false;
    }

    // ---------- Selection ----------
    private void TryBeginDrag()
    {
        if (EventSystem.current && EventSystem.current.IsPointerOverGameObject())
            return;

        Camera cam = Camera.main;
        if (!cam)
        {
            Debug.LogWarning("[YScaler] No Camera.main found. Tag your active camera as MainCamera.");
            return;
        }

        Ray ray = cam.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out RaycastHit hit, 5000f, selectableLayers, QueryTriggerInteraction.Ignore))
        {
            Transform root = ResolvePlanetRoot(hit.transform);
            if (!IsPlanet(root))
            {
                Debug.Log($"[YScaler] Hit non-planet: {root?.name ?? "null"}");
                return;
            }

            selectedObject = root;
            lastMousePosition = Input.mousePosition;
            isDragging = true;
            Debug.Log($"[YScaler] Selected {selectedObject.name}");
        }
        else
        {
            Debug.Log("[YScaler] Raycast missed.");
        }
    }

    private Transform ResolvePlanetRoot(Transform t) => t ? t.root : null;

    private bool IsPlanet(Transform candidate)
    {
        if (!candidate) return false;

        // Direct ref match
        if (candidate == Sun || candidate == Earth || candidate == Moon)
            return true;

        // Tag fallback
        if (allowTagFallback)
        {
            if (candidate.CompareTag("Sun") || candidate.CompareTag("Earth") || candidate.CompareTag("Moon"))
                return true;
        }

        return false;
    }
}

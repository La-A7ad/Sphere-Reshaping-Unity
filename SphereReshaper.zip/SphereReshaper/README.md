# Sphere Reshaper (Unity)

Open in Unity 2022.3.21f1+, load `Assets/Scenes/Main.unity`, hit Play.

using UnityEngine;
using SphereReshaper.Metrics;   

namespace SphereReshaper.Scaling
{
    public class UniformScaler : MonoBehaviour
    {
        [SerializeField] private float scaleStep = 0.5f;  // smaller value + Time.deltaTime
        [SerializeField] private SphericityMeter meter;   //I should assign this in inspector

        private void Update(){
            float s = Input.mouseScrollDelta.y;
            if (Mathf.Abs(s) > 0.0001f){
                float factor = 1f + (s * scaleStep * Time.deltaTime);
                float uni = Mathf.Clamp(transform.localScale.x * factor, 0.1f, 10f);
                transform.localScale = new Vector3(uni, uni, uni);
            }
        }

        public float GetDiameter(){
            if (meter != null && meter.MeanRadiusWorld > 0f) return meter.MeanRadiusWorld * 2f;
            // fallback if meter not set:
            var r = GetComponent<Renderer>();
            return r ? r.bounds.size.x : transform.lossyScale.x; // last resort
        }
    }
}

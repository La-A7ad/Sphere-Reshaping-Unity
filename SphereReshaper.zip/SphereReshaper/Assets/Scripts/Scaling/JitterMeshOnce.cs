using UnityEngine;

[RequireComponent(typeof(MeshFilter))]
public class JitterMeshOnce : MonoBehaviour {
    [Range(0f, 0.15f)] public float amplitude = 0.04f;   // overall bump height
    [Range(0.1f, 4f)]  public float frequency = 1.8f;    // bump density
    public int seed = 12345;

    void Start() {
        var mf = GetComponent<MeshFilter>();
        var src = mf.sharedMesh;
        var mesh = Instantiate(src);         // don’t touch the asset
        var v = mesh.vertices;
        var n = mesh.normals;
        var rMax = 0f; foreach (var p in v) rMax = Mathf.Max(rMax, p.magnitude);

        var rand = new System.Random(seed);
        float ox = (float)rand.NextDouble()*10f, oy = (float)rand.NextDouble()*10f, oz = (float)rand.NextDouble()*10f;

        for (int i = 0; i < v.Length; i++) {
            // fake 3D noise by blending 2D Perlin samples
            var p = v[i].normalized; // direction only
            float a = Mathf.PerlinNoise(p.x*frequency + ox, p.y*frequency + oy);
            float b = Mathf.PerlinNoise(p.y*frequency + oy, p.z*frequency + oz);
            float t = (a + b) * 0.5f;             // 0..1
            float delta = (t * 2f - 1f) * amplitude;

            v[i] = v[i] + n[i] * delta;           // move along the normal
        }

        mesh.vertices = v;
        mesh.RecalculateNormals(); mesh.RecalculateBounds();
        mf.sharedMesh = mesh;
        Destroy(this); // one-time
    }
}

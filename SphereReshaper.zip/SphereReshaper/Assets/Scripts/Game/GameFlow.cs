using UnityEngine; using SphereReshaper.Metrics; using SphereReshaper.Scaling;
using SphereReshaper.Deformer;

namespace SphereReshaper.Game
{
    public enum Phase { Deform, Resize, Done }

    public class GameFlow : MonoBehaviour
    {
        [Header("Refs")]
        [SerializeField] private SphericityMeter meter;
        [SerializeField] private UniformScaler scaler;
        [SerializeField] private MouseDeformer deformer;
        [SerializeField] private RingIndicator ring;   // NEW (see script below)

        [Header("Tuning")]
        [SerializeField] private float sphericityThreshold = 0.95f;
        [SerializeField] private float targetDiameter = 1.0f;
        [SerializeField] private float targetTolerancePct = 0.05f;

        public Phase Current { get; private set; } = Phase.Deform;

        void Start(){ EnterDeform(); }

        void Update(){
            switch (Current)
            {
                case Phase.Deform:
                    if (meter && meter.Score >= sphericityThreshold) EnterResize();
                    break;

                case Phase.Resize:
                    if (scaler != null){
                        float d = scaler.GetDiameter();
                        float pct = Mathf.Abs(d - targetDiameter) / Mathf.Max(0.0001f, targetDiameter);
                        if (pct <= targetTolerancePct) EnterDone();
                        else if (ring) ring.SetError(pct / targetTolerancePct); // 1=bad, 0=good
                    }
                    break;
            }
        }

        void EnterDeform(){
            Current = Phase.Deform;
            if (deformer) deformer.enabled = true;
            if (scaler) scaler.enabled = false;
            if (ring) ring.gameObject.SetActive(false);
        }

        void EnterResize(){
            Current = Phase.Resize;
            if (deformer) deformer.enabled = false;
            if (scaler) scaler.enabled = true;
            if (ring){
                ring.gameObject.SetActive(true);
                ring.SetRadius(targetDiameter * 0.5f);
                ring.SetError(1f);
            }
        }

        void EnterDone(){
            Current = Phase.Done;
            if (deformer) deformer.enabled = false;
            if (scaler) scaler.enabled = false;
            if (ring) ring.gameObject.SetActive(false);
            OnCompleted();
        }

        private void OnCompleted(){ Debug.Log("All targets met! Trigger narration here."); }
    }
}

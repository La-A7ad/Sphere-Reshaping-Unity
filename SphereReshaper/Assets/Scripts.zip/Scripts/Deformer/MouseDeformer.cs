using UnityEngine;

namespace SphereReshaper.Deformer
{
    [RequireComponent(typeof(MeshFilter), typeof(MeshCollider))]
    public class MouseDeformer : MonoBehaviour
    {
        [Header("Deform")]
        [SerializeField] private float deformRadius = 0.25f;
        [SerializeField] private float strength = 0.5f;
        [SerializeField, Range(1f, 5f)] private float falloffPower = 2f;
        [SerializeField] private Camera cam;

        Mesh _mesh; MeshCollider _collider; Vector3[] _verts;
        bool _dragging; Vector3 _lastHit;

        void Awake(){
            _mesh = GetComponent<MeshFilter>().mesh;
            _verts = _mesh.vertices;
            _collider = GetComponent<MeshCollider>();
            if (!cam) cam = Camera.main;
            _mesh.MarkDynamic();
        }

        void Update(){
            if (!cam) return;

            if (Input.GetMouseButton(0)){
                var ray = cam.ScreenPointToRay(Input.mousePosition);
                if (Physics.Raycast(ray, out var hit, 1000f) && hit.collider.transform == transform){
                    DeformAt(hit.point, hit.normal);
                    _dragging = true; _lastHit = hit.point;
                }
            } else if (_dragging){
                // refresh collider only when mouse released
                if (_collider){ _collider.sharedMesh = null; _collider.sharedMesh = _mesh; }
                _dragging = false;
            }
        }

        void DeformAt(Vector3 hitPointW, Vector3 hitNormalW){
            var tf = transform;
            for (int i = 0; i < _verts.Length; i++){
                var pW = tf.TransformPoint(_verts[i]);
                float d = Vector3.Distance(pW, hitPointW);
                if (d > deformRadius) continue;
                float w = Mathf.Pow(1f - (d / deformRadius), falloffPower);
                pW += hitNormalW * (strength * w * Time.deltaTime);
                _verts[i] = tf.InverseTransformPoint(pW);
            }
            _mesh.vertices = _verts;
            _mesh.RecalculateNormals(); _mesh.RecalculateBounds();
        }

        void OnDrawGizmosSelected(){
            if (_dragging){ Gizmos.color = Color.yellow; Gizmos.DrawWireSphere(_lastHit, deformRadius); }
        }
    }
}

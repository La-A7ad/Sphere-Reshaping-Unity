using UnityEngine;
using SphereReshaper.Metrics;
using SphereReshaper.Scaling;
using SphereReshaper.Deformer;

namespace SphereReshaper.Game
{
    public enum Phase { Deform, Resize, Done }

    public class GameFlow : MonoBehaviour
    {
        [Header("Refs")]
        [SerializeField] private SphericityMeter meter;
        [SerializeField] private TwoStageScaler scaler;
        [SerializeField] private MouseDeformer deformer;
        [SerializeField] private RingIndicator ring;

        [Header("Tuning")]
        [SerializeField, Range(0.7f,0.99f)] private float sphericityThreshold = 0.95f;
        [SerializeField] private float targetDiameter = 1.2f;
        [SerializeField] private float targetTolerancePct = 0.05f;

        public Phase Current { get; private set; } = Phase.Deform;

        void Start(){ EnterDeform(); }

        void Update(){
            switch (Current){
                case Phase.Deform:
                    if (meter && meter.Score >= sphericityThreshold) EnterResize();
                    break;

                case Phase.Resize:
    if (!scaler) break;
    if (scaler.YLocked) {
        if (scaler.IsDiameterOk()) EnterDone();
    } else {
        // still adjusting Y — you could show a UI hint "Adjust Y height"
    }
    break;
            }
        }

        void EnterDeform(){
            Current = Phase.Deform;
            if (deformer) deformer.enabled = true;
            if (scaler) scaler.enabled = false;
            if (ring) ring.gameObject.SetActive(false);
        }

        void EnterResize(){
    Current = Phase.Resize;
    if (deformer) deformer.enabled = false;
    if (scaler){
        scaler.enabled = true;
        if (scaler.ring) scaler.ring.gameObject.SetActive(false); // will show when Y locks
    }
}


        void EnterDone(){
            Current = Phase.Done;
            if (deformer) deformer.enabled = false;
            if (scaler) scaler.enabled = false;
            if (ring) ring.gameObject.SetActive(false);
            OnCompleted();
        }

        void OnCompleted(){
            Debug.Log("All targets met! Trigger narration here.");
            // TODO: hook AudioNarrator
        }
    }
}

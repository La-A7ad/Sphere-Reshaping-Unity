using UnityEngine;
using SphereReshaper.Metrics; // for MeanRadiusWorld

namespace SphereReshaper.Scaling
{
    public class TwoStageScaler : MonoBehaviour
    {
        [Header("Stage 1: Y-only")]
        public float targetYScale = 1.0f;
        [Range(0.0f, 0.2f)] public float yTolerancePct = 0.02f; // ±2%
        public float yDragSpeed = 2.0f;  // drag ↑/↓ changes Y

        [Header("Stage 2: Uniform")]
        public float uniformSensitivity = 1.5f; // drag ↑/↓ scales all axes
        public float minScale = 0.2f, maxScale = 5f;

        [Header("Target Diameter (optional)")]
        public SphericityMeter meter;       // assign for accurate diameter
        public float targetDiameter = 1.2f; // world units
        public float diameterTolerancePct = 0.05f; // ±5%

        [Header("Visuals (optional)")]
        public RingIndicator ring;          // show after Y is locked

        public bool YLocked { get; private set; }

        float _lastMouseY;
        bool _dragging;

        void OnEnable() { YLocked = false; }

        void Update()
        {
            if (Input.GetMouseButtonDown(0)) { _dragging = true; _lastMouseY = Input.mousePosition.y; }
            if (Input.GetMouseButtonUp(0))   { _dragging = false; }

            if (!_dragging) return;

            float mouseY = Input.mousePosition.y;
            float dy = (mouseY - _lastMouseY) / Mathf.Max(1f, Screen.height); // normalized per screen height
            _lastMouseY = mouseY;

            if (!YLocked)
            {
                // Stage 1: adjust Y only
                float y = transform.localScale.y * (1f + dy * yDragSpeed);
                y = Mathf.Clamp(y, minScale, maxScale);
                transform.localScale = new Vector3(transform.localScale.x, y, transform.localScale.z);

                if (IsYWithinTolerance())
                {
                    // snap and lock
                    var s = transform.localScale; s.y = targetYScale; transform.localScale = s;
                    YLocked = true;

                    if (ring)
                    {
                        ring.gameObject.SetActive(true);
                        ring.SetRadius(targetDiameter * 0.5f);
                        ring.Redraw();
                        ring.SetError(1f); // start "far"
                    }
                }
            }
            else
            {
                // Stage 2: uniform scaling on drag
                float factor = 1f + dy * uniformSensitivity;
                factor = Mathf.Clamp(factor, 0.5f, 1.5f); // per-frame clamp
                var s = transform.localScale * factor;
                float uni = Mathf.Clamp(s.x, minScale, maxScale);
                transform.localScale = new Vector3(uni, uni, uni);

                // optional ring feedback to target diameter
                if (ring) ring.SetError(GetDiameterErrorRatio());
            }
        }

        public bool IsYWithinTolerance()
        {
            float y = transform.localScale.y;
            return Mathf.Abs(y - targetYScale) <= targetYScale * yTolerancePct;
        }

        public bool IsDiameterOk() => GetDiameterErrorRatio() <= 1f;

        float GetDiameterErrorRatio()
        {
            float d = GetDiameter();
            float errPct = Mathf.Abs(d - targetDiameter) / Mathf.Max(0.0001f, targetDiameter);
            return errPct / diameterTolerancePct; // <=1 == within tolerance
        }

        public float GetDiameter()
        {
            if (meter && meter.MeanRadiusWorld > 0f) return meter.MeanRadiusWorld * 2f;
            var r = GetComponent<Renderer>();
            return r ? r.bounds.size.x : transform.lossyScale.x;
        }
    }
}
